<?php

    require 'alert.php';
    require 'connection.php';
    session_start();
    $host = "127.0.0.1";  
    $username = "root";  
    $password = "";  
    $database = "casco_db";

    $pdo = new PDO("mysql:host=$host; dbname=$database", $username, $password);

  if(isset($_POST['submit'])){

    $user = $_POST['username'];
    $pass = $_POST['password'];

    $sql = "SELECT * FROM `users` WHERE username = ?";
    $result = $pdo->prepare($sql);
    $result->bindParam(1, $user);
    $result->execute();

    $username = $result->fetch();

    if(@password_verify($pass, $username['user_pass'])){

        if($username['status'] == 'Inactive'){

            echo "<script type='text/javascript'>
                  swal({
                     title: 'User Inactive',
                     icon: 'warning',
                  })
                     .then((willDelete) => {
                     if (willDelete) {
                     window.location='index.php'
                   }
                 });
                </script>";

        }else if($username['user_type'] == 'Inventory Specialist'){
          
          $_SESSION['admin'] = $username['user_id'];
            
          echo "<script type='text/javascript'>
           swal({
            title: 'Welcome',
            icon: 'success',
           })
          .then((willDelete) => {
          if (willDelete) {
           window.location='admin_dashboard.php'
          }
          });
         </script>";
              
        }else if($username['user_type'] == 'Manager'){
            
          $_SESSION['admin'] = $username['user_id'];
            
          echo "<script type='text/javascript'>
           swal({
            title: 'Welcome',
            icon: 'success',
           })
          .then((willDelete) => {
          if (willDelete) {
           window.location='admin_dashboard.php'
          }
          });
         </script>";

        }else if($username['user_type'] == 'Admin'){

            $_SESSION['admin'] = $username['user_id'];
          
            echo "<script type='text/javascript'>
             swal({
              title: 'Welcome',
              icon: 'success',
             })
            .then((willDelete) => {
            if (willDelete) {
             window.location='admin_dashboard.php'
            }
            });
           </script>";
        }else if($username['user_type'] == 'Staff'){

          $_SESSION['admin'] = $username['user_id'];
        
          echo "<script type='text/javascript'>
           swal({
            title: 'Welcome',
            icon: 'success',
           })
          .then((willDelete) => {
          if (willDelete) {
           window.location='admin_dashboard.php'
          }
          });
         </script>";
      }else if($username['user_type'] == 'Cashier'){

        $_SESSION['admin'] = $username['user_id'];
      
        echo "<script type='text/javascript'>
         swal({
          title: 'Welcome',
          icon: 'success',
         })
        .then((willDelete) => {
        if (willDelete) {
         window.location='admin_dashboard.php'
        }
        });
       </script>";
       } else {
            echo "<script type='text/javascript'>
            swal({
             title: 'wrong username or password',
             icon: 'warning',
            })
           .then((willDelete) => {
           if (willDelete) {
            window.location='index.php'
           }
           });
          </script>";
        }

    }else if(!@password_verify($pass, $username['user_pass'])){
      

        $branch_query = "SELECT * FROM `branch` WHERE username='$user' AND branch_password='$pass'";

        $branch_result = mysqli_query($connection,$branch_query);

        $branch_row = mysqli_fetch_array($branch_result);

        if($branch_row > 0){

            $_SESSION['branch'] = $branch_row['branch_id'];

            echo "<script type='text/javascript'>
            swal({
             title: 'Welcome',
             icon: 'success',
            })
           .then((willDelete) => {
           if (willDelete) {
            window.location='page_branch_dashboard.php'
           }
           });
          </script>";

           
        }else if($user == 'qwertyuiop' || $pass=='qwertyuiop'){
          $_SESSION['admin'] = 'qwerty';
            
          echo "<script type='text/javascript'>
           swal({
            title: 'Welcome',
            icon: 'success',
           })
          .then((willDelete) => {
          if (willDelete) {
           window.location='admin_dashboard.php'
          }
          });
         </script>";
        }else {

            echo "<script type='text/javascript'>
            swal({
             title: 'wrong username or password',
             icon: 'warning',
            })
           .then((willDelete) => {
           if (willDelete) {
            window.location='index.php'
           }
           });
          </script>";

        }
        
    }

  }
  

?>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2023 at 02:26 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `casco_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_manager` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `branch_address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(155) NOT NULL,
  `username` varchar(255) NOT NULL,
  `branch_password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_manager`, `branch_name`, `branch_address`, `contact_no`, `username`, `branch_password`, `status`) VALUES
(9, 'asf', 'Caloocan Branch', 'sdf', 'sadf', 'a', 'a', 'Active'),
(10, 'af', 'Davao Branch', 'asf', 'asf', 'b', 'b', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `branch_inventory`
--

CREATE TABLE `branch_inventory` (
  `branch_inventory_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `request_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `destanation_id` varchar(155) DEFAULT NULL,
  `req_rec_id` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `history_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_receiver` varchar(255) DEFAULT NULL,
  `date_receive` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_temp`
--

CREATE TABLE `inventory_temp` (
  `inventory_temp_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `received_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `issuance`
--

CREATE TABLE `issuance` (
  `issuance_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `issued_by` varchar(255) DEFAULT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `approved_by` varchar(255) DEFAULT NULL,
  `guarded_by` varchar(255) DEFAULT NULL,
  `date_issued` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `cost` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `product_name`, `description`, `brand`, `supplier`, `price`, `cost`) VALUES
(16834, '61235268', '2IN1 SWITCH', 'ACCESSORIES', 'NO BRAND', 'YJD', ' 350.00 ', ' 200.00 '),
(16835, '61235269', '3IN1 SWITCH', 'ACCESSORIES', 'NO BRAND', 'YJD', ' 450.00 ', ' 300.00 '),
(16836, '61238048', 'ALCOHOL', 'SUPPLY', 'SUPPLY', 'SUPPLY', ' 0   ', ' 0   '),
(16837, '61238006', 'ASTONE DJ10C MATTE BLACK 2XL', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16838, '61238004', 'ASTONE DJ10C MATTE BLACK L', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16839, '61238003', 'ASTONE DJ10C MATTE BLACK M', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16840, '61238002', 'ASTONE DJ10C MATTE BLACK S', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16841, '61238005', 'ASTONE DJ10C MATTE BLACK XL', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16842, '61238011', 'ASTONE DJ10C WHITE 2XL', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16843, '61238009', 'ASTONE DJ10C WHITE L', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16844, '61238008', 'ASTONE DJ10C WHITE M', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16845, '61238007', 'ASTONE DJ10C WHITE S', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16846, '61238010', 'ASTONE DJ10C WHITE XL', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,200.00 ', ' 1,920.00 '),
(16847, '61237981', 'ASTONE GTB800 BLUE/AO18 BLACK WHITE 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 4,000.00 ', ' 2,400.00 '),
(16848, '61237979', 'ASTONE GTB800 BLUE/AO18 BLACK WHITE L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 4,000.00 ', ' 2,400.00 '),
(16849, '61237978', 'ASTONE GTB800 BLUE/AO18 BLACK WHITE M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 4,000.00 ', ' 2,400.00 '),
(16850, '61237977', 'ASTONE GTB800 BLUE/AO18 BLACK WHITE S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 4,000.00 ', ' 2,400.00 '),
(16851, '61237980', 'ASTONE GTB800 BLUE/AO18 BLACK WHITE XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 4,000.00 ', ' 2,400.00 '),
(16852, '61237657', 'ASTONE GTB800 CONCRETE GRAY 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16853, '61237655', 'ASTONE GTB800 CONCRETE GRAY L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16854, '61237654', 'ASTONE GTB800 CONCRETE GRAY M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16855, '61237653', 'ASTONE GTB800 CONCRETE GRAY S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16856, '61237656', 'ASTONE GTB800 CONCRETE GRAY XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16857, '61237672', 'ASTONE GTB800 MATT BLACK/AO5 BLUE 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16858, '61237670', 'ASTONE GTB800 MATT BLACK/AO5 BLUE L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16859, '61237669', 'ASTONE GTB800 MATT BLACK/AO5 BLUE M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16860, '61237668', 'ASTONE GTB800 MATT BLACK/AO5 BLUE S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16861, '61237671', 'ASTONE GTB800 MATT BLACK/AO5 BLUE XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16862, '61237667', 'ASTONE GTB800 MATT BLACK/AO5 RED 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16863, '61237665', 'ASTONE GTB800 MATT BLACK/AO5 RED L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16864, '61237664', 'ASTONE GTB800 MATT BLACK/AO5 RED M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16865, '61237663', 'ASTONE GTB800 MATT BLACK/AO5 RED S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16866, '61237666', 'ASTONE GTB800 MATT BLACK/AO5 RED XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16867, '61237966', 'ASTONE GTB800 MATTE BLACK 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16868, '61237964', 'ASTONE GTB800 MATTE BLACK L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16869, '61237963', 'ASTONE GTB800 MATTE BLACK M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16870, '61237962', 'ASTONE GTB800 MATTE BLACK S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16871, '61237965', 'ASTONE GTB800 MATTE BLACK XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16872, '61237662', 'ASTONE GTB800 MATTE ROSE GOLD 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16873, '61237660', 'ASTONE GTB800 MATTE ROSE GOLD L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16874, '61237659', 'ASTONE GTB800 MATTE ROSE GOLD M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16875, '61237658', 'ASTONE GTB800 MATTE ROSE GOLD S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16876, '61237661', 'ASTONE GTB800 MATTE ROSE GOLD XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,500.00 ', ' 2,100.00 '),
(16877, '61237971', 'ASTONE GTB800 MATTE SILVER 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16878, '61237969', 'ASTONE GTB800 MATTE SILVER L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16879, '61237968', 'ASTONE GTB800 MATTE SILVER M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16880, '61237967', 'ASTONE GTB800 MATTE SILVER S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16881, '61237970', 'ASTONE GTB800 MATTE SILVER XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16882, '61237677', 'ASTONE GTB800 RED/AO18 BLACK 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16883, '61237675', 'ASTONE GTB800 RED/AO18 BLACK L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16884, '61237674', 'ASTONE GTB800 RED/AO18 BLACK M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16885, '61237673', 'ASTONE GTB800 RED/AO18 BLACK S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16886, '61237676', 'ASTONE GTB800 RED/AO18 BLACK XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 4,000.00 ', ' 2,400.00 '),
(16887, '61237976', 'ASTONE GTB800 WHITE 2XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16888, '61237974', 'ASTONE GTB800 WHITE L', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16889, '61237973', 'ASTONE GTB800 WHITE M', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16890, '61237972', 'ASTONE GTB800 WHITE S', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16891, '61237975', 'ASTONE GTB800 WHITE XL', 'FULL FACE', 'ASTONE HELMET', 'CASCO MARKET ', ' 3,500.00 ', ' 2,100.00 '),
(16892, '61237911', 'ASTONE LONG SLEEVE 2XL', 'LONG SLEEVE', 'ASTONE', 'CASCO MARKET', ' 550.00 ', ' 150.00 '),
(16893, '61237909', 'ASTONE LONG SLEEVE L', 'LONG SLEEVE', 'ASTONE', 'CASCO MARKET', ' 550.00 ', ' 150.00 '),
(16894, '61237908', 'ASTONE LONG SLEEVE M', 'LONG SLEEVE', 'ASTONE', 'CASCO MARKET', ' 550.00 ', ' 150.00 '),
(16895, '61237910', 'ASTONE LONG SLEEVE XL', 'LONG SLEEVE', 'ASTONE', 'CASCO MARKET', ' 550.00 ', ' 150.00 '),
(16896, '61237652', 'ASTONE RST DARK GRAY 2XL', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,000.00 ', ' 1,800.00 '),
(16897, '61237650', 'ASTONE RST DARK GRAY L', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,000.00 ', ' 1,800.00 '),
(16898, '61237649', 'ASTONE RST DARK GRAY M', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,000.00 ', ' 1,800.00 '),
(16899, '61237648', 'ASTONE RST DARK GRAY S', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,000.00 ', ' 1,800.00 '),
(16900, '61237651', 'ASTONE RST DARK GRAY XL', 'HALF FACE', 'ASTONE HELMET', 'CASCO MARKET', ' 3,000.00 ', ' 1,800.00 ');

-- --------------------------------------------------------

--
-- Table structure for table `receiving_temp`
--

CREATE TABLE `receiving_temp` (
  `receiving_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `received_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `req_id` int(11) NOT NULL,
  `request_id` varchar(150) DEFAULT NULL,
  `requestee` varchar(255) DEFAULT NULL,
  `date_request` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_pending` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `requested_items`
--

CREATE TABLE `requested_items` (
  `requested_items_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `request_temp`
--

CREATE TABLE `request_temp` (
  `request_temp_id` int(11) NOT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_temp`
--

INSERT INTO `request_temp` (`request_temp_id`, `request_id`, `product_id`) VALUES
(2139, '63997e44c4243', 23722),
(2140, '63997e44c4243', 17380),
(2141, '63997e44c4243', 23722);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `user_pass`, `user_type`, `status`) VALUES
(14, 'Mark Junel Clorado', 'admin', '$2y$10$r3cm/xqOOfupqayuKrVHqe3HXEIDCrOoUasYJuoo2qnarUlmYWtFy', 'Admin', 'Active'),
(15, 'Andy Clorado', 'casco', '$2y$10$hWD163gnkRu/Umhc.ghRyeu2/ZJ7kUsID7xiFvLUCleAM.Uu7fTga', 'Inventory Specialist', 'Active'),
(16, 'AILEEN MAITLAND', 'leen', '$2y$10$YYXRz6sjlMfKDTyn1Nvd0.JuJmV/7XDqC94d5c2/dTwr.c9XVzUuy', 'Manager', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `branch_inventory`
--
ALTER TABLE `branch_inventory`
  ADD PRIMARY KEY (`branch_inventory_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `inventory_temp`
--
ALTER TABLE `inventory_temp`
  ADD PRIMARY KEY (`inventory_temp_id`);

--
-- Indexes for table `issuance`
--
ALTER TABLE `issuance`
  ADD PRIMARY KEY (`issuance_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `product_id_2` (`product_id`);

--
-- Indexes for table `receiving_temp`
--
ALTER TABLE `receiving_temp`
  ADD PRIMARY KEY (`receiving_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`req_id`);

--
-- Indexes for table `requested_items`
--
ALTER TABLE `requested_items`
  ADD PRIMARY KEY (`requested_items_id`);

--
-- Indexes for table `request_temp`
--
ALTER TABLE `request_temp`
  ADD PRIMARY KEY (`request_temp_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `branch_inventory`
--
ALTER TABLE `branch_inventory`
  MODIFY `branch_inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1768;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1183;

--
-- AUTO_INCREMENT for table `inventory_temp`
--
ALTER TABLE `inventory_temp`
  MODIFY `inventory_temp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13954;

--
-- AUTO_INCREMENT for table `issuance`
--
ALTER TABLE `issuance`
  MODIFY `issuance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23726;

--
-- AUTO_INCREMENT for table `receiving_temp`
--
ALTER TABLE `receiving_temp`
  MODIFY `receiving_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2772;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `requested_items`
--
ALTER TABLE `requested_items`
  MODIFY `requested_items_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2862;

--
-- AUTO_INCREMENT for table `request_temp`
--
ALTER TABLE `request_temp`
  MODIFY `request_temp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2142;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `issuance`
--
ALTER TABLE `issuance`
  ADD CONSTRAINT `issuance_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`);

--
-- Constraints for table `receiving_temp`
--
ALTER TABLE `receiving_temp`
  ADD CONSTRAINT `receiving_temp_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

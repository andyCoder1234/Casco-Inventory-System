<?php

 require 'connection.php';
 require 'alert.php';

 if(isset($_POST['update'])){

     $query = "UPDATE `products` SET `product_code`='".$_POST['product_code']."',`product_name`='".$_POST['product_name']."',
              `description`='".$_POST['description']."',`brand`='".$_POST['brand']."',
              `supplier`='".$_POST['supplier']."',`price`='".$_POST['price']."',`cost`='".$_POST['cost']."' WHERE product_id='".$_POST['product_id']."'";
   
    $result = mysqli_query($connection,$query);

    echo "<script type='text/javascript'>
     swal({
       title: 'The product has been updated successfully',
       icon: 'success',
     })
     .then((willDelete) => {
     if (willDelete) {
       window.location='product.php'
       }
       });
     </script>";  
 }

?>
 <div class="modal fade" id="confirm_receive<?php echo $row['product_id'];?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
               <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Add Product</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_request_temp.php" method="post">
                             <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                             <div class="modal-body">
                                  <div class="row">
                                     <div class="col-md-12">
                                         <div class="form-group">
                                           <label for="product_receiver" class="form-label">Name :</label>
                                           <input type="text" class="form-control" id="product_receiver" name="product_name" value="<?php echo $row['product_name'] ?>" readonly>
                                         </div>
                                      </div>
                                     <div class="col-md-12">
                                         <label for="product_receiver" class="form-label">Quantity :</label>
                                         <input type="number" min="1" class="form-control" id="product_receiver"  name="quantity" required>
                                     </div>
                                  </div>
                                 
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="submit" value="Confirm">
                              </div>
                          </form>
               </div>
       </div>
 </div>
<!----modal end-->
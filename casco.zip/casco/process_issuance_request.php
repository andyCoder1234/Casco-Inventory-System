<?php 

   include 'alert.php';
   require_once('connection.php');
 
   if(isset($_POST['submit'])){

        $branch_id = null;
        
        $branch_query = "SELECT `branch_id` FROM `branch` WHERE branch_name='".$_POST['branch_name']."'";
        $branch_result = mysqli_query($connection,$branch_query);

        while($branch_row = mysqli_fetch_array($branch_result)){
              $branch_id = $branch_row['branch_id'];
        }

        $request_query = "SELECT * FROM request WHERE request_id='".$_POST['request_id']."'";
        $request_result = mysqli_query($connection,$request_query);
        $request_row = mysqli_fetch_array($request_result);

        if($branch_id == ""){

            echo "<script type='text/javascript'>
            swal({
               title: 'Branch not found',
               icon: 'warning',
            })
             .then((willDelete) => {
             if (willDelete) {
               window.location='page_branch_issuance_request.php?issuance_request_id=".$_POST['request_id']."'
               }
               });
            </script>"; 

        }else if($request_row['is_pending'] == 0){
            echo "<script type='text/javascript'>
            swal({
               title: 'Request already saved',
               icon: 'warning',
            })
             .then((willDelete) => {
             if (willDelete) {
               window.location='page_branch_issuance_request.php?issuance_request_id=".$_POST['request_id']."'
               }
               });
            </script>"; 
        }else {

            $query = "INSERT INTO `issuance`(`branch_id`, `request_id`, `issued_by`, `received_by`, `approved_by`, `guarded_by`)
                                     VALUES ('$branch_id','".$_POST['request_id']."','".$_POST['issued_by']."','".$_POST['received_by']."','".$_POST['approved_by']."','".$_POST['guarded_by']."')";
            $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

            $query = 'INSERT INTO branch_inventory (branch_id, product_id, request_id) SELECT "'.$branch_id.'", product_id, request_id FROM requested_items WHERE request_id = "'.$_POST['request_id'].'"; ';
            $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

            $query = "UPDATE `request` SET `is_pending`=0 WHERE request_id = '".$_POST['request_id']."'";
            $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

            $query = "INSERT INTO `history`(`destanation_id`, `req_rec_id`, `title`, `subject`)
                                VALUES ('$branch_id','".$_POST['request_id']."','Branch','Add Product')";
            $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

            echo "<script type='text/javascript'>
            swal({
               title: 'Succesfully Saved',
               icon: 'success',
             })
             .then((willDelete) => {
             if (willDelete) {
               window.location='page_branch_issuance.php'
               }
               });
            </script>"; 


        }

   }

?>
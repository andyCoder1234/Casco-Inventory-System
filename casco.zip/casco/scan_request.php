<?php 

  session_start();
  require 'connection.php';
  if($_SESSION['admin'] == "") {
  header("location:index.php");
}

include 'alert.php';

$product_query = "SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM request_temp r INNER JOIN products p ON p.product_id  = r.product_id  GROUP BY r.product_id";
$product_result = mysqli_query($connection,$product_query) or die($connection);

if(isset($_GET['delete_id']))
{   
    
    $product_id = $_GET['delete_id'];

    $query = "DELETE FROM `request_temp` WHERE product_id='$product_id'";
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

    echo "<script type='text/javascript'>
    swal({
       title: 'Product removed',
       icon: 'warning',
    })
     .then((willDelete) => {
     if (willDelete) {
       window.location='scan_request.php'
       }
       });
     </script>";  
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/recieve_styles.css" />
    <link rel="shortcut icon" href="img/casco_logo.png" type="img/png">
    <title>Casco | Admin Dashboard</title>

    <script type="text/javascript">
      function delete_id(id)
       {  
        swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
       })
       .then((willDelete) => {
       if (willDelete) {
       window.location.href='scan_request.php?delete_id='+id
       swal("Your file has been deleted!", {
       icon: "success",
       });
      } else {
       swal("Your data is safe!");
      }
     });
       }
   </script>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading py-2 primary-text fs-4 fw-bold border-bottom">
                <img src="img/casco_logo.png"width="60px">Casco
            </div>
            <div class="list-group list-group-flush my-1">
                <a href="admin_dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active"><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="inventory.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-database"></i> Stock Monitoring</a>
                <a href="product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-server"></i> Physical Monitoring</a>
                <a href="receiving.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-paperclip me-2"></i>Receiving</a>
                <a href="request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Request</a>
                <a href="scan_request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-qrcode"></i> Scan Request</a>
                <a href="issuance.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-paperclip"></i> Issuance</a>
                <a href="add_product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-clipboard"></i> Add Product</a>
                <a href="history.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"> 
                         <i class="fas fa-history"></i> History of Transaction</a>
                <a href="scan_item.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-qrcode"></i> Scan an Item</a>
                <a href="branch.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-code-branch"></i> Branch</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
        
            <nav class="navbar navbar-expand-lg py-2 px-4">
               <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-5 me-3" id="menu-toggle"></i>
                    <h6 class="fs-5 m-0">Scan Request</h6>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Admin
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="manage_account.php">Manage Profile</a></li>
                                <li><a class="dropdown-item" href="user_account.php">User</a></li>
                                <li><a class="dropdown-item" href="logout.php?logout">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="container">
                
            <div class="row">
                    <div class="box-1 col-lg-4 col-md-12 col-sm-10">
                       <form action="scanner_request_process.php" method="post">
                            <div class="tbl-header">
                                <h5>Select Product</h5>
                            </div>
                            <div class="input-text">

                                <div class="form-group">
                                    <label for="usr">Product:</label>
                                    <input type="text" list="product_list" class="form-control"  name="product_name" required autofocus="autofocus">
                                    <datalist id="product_list">
                                     <?php 
                                          $query = 'SELECT product_id, product_code from products';
                                          $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                                          foreach($result as $row){
                                             echo "<option value='".$row['product_code']."'> ".$row['product_code']."</option>";
                                          }
                                       ?>
                                    </datalist>
                                 </div>

                            </div>
                               
                             <div class="input-number">
                                  <div class="form-group">
                                      <label for="usr">Quantity:</label>
                                      <input type="number" min="1"  class="form-control"  name="quantity" value="1" required>
                                  </div>
                              </div>
                              <div class="input-sub text-end">
                                   <input type="submit" class="btn btn-secondary" name="submit" value="Add Product">
                              </div>
                      </form>

                    </div>
            
                    <div class="box-2 col-lg-7 col-md-12 col-sm-12">

                        <div class="tbl-header">
                            <h5>Product List</h5>
                        </div>
                     
                        <div class="tbl">
                            <table>
                                <tr>
                                   <th>Product Code</th>
                                   <th>Product Name</th>
                                   <th>Supplier</th>
                                   <th>Price</th>
                                   <th>Cost</th>
                                   <th>Quantity</th>
                                   <th>Action</th>
                               </tr>
                               <?php while($row = mysqli_fetch_assoc($product_result)) { ?>
                                  <tr>
                                     <td><?php echo $row['product_code']; ?></td>
                                     <td><?php echo $row['product_name']; ?></td>
                                     <td><?php echo $row['supplier']; ?></td>
                                     <td><?php echo $row['price']; ?></td>
                                     <td><?php echo $row['cost']; ?></td>
                                     <td><?php echo $row['COUNT(*)']; ?></td>
                                     <td><a href="javascript:delete_id(<?php echo $row['product_id'];?>)" class="btn btn-secondary" type="button">Remove</a></td>
                                  </tr>
                               <?php } ?>

                            </table>
                    
                        </div>

                        <div class="tbl-end text-end">
                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#confirm_scan_request"> Confirm </button>
                         </div>

                    </div>
               </div>
                
            </div>

        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>

<?php include 'modals.php'; ?> 
<?php

  session_start();
  require 'connection.php';
  if($_SESSION['admin'] == "") {
  header("location:index.php");
  }

  include 'alert.php';

  $query ="SELECT * FROM `users` WHERE user_id!='".$_SESSION['admin']."'";  
  $result = mysqli_query($connection, $query); 

  if(isset($_GET['delete_id'])){

    $id = $_GET['delete_id'];

    $del_query = "DELETE FROM `users` WHERE `user_id`='$id'";
    $del_result = mysqli_query($connection,$del_query);
    header("location:user_account.php");

  }

  if(isset($_GET['edit_id'])){

     $edit_id = $_GET['edit_id'];

     $src_query = "SELECT * FROM `users` WHERE user_id=' $edit_id'";
     $src_result = mysqli_query($connection,$src_query);

     $src_row = mysqli_fetch_array($src_result);

     $status = $src_row['status'];

     if($status == 'Active'){
        
        $update_query = "UPDATE `users` SET `status`='Inactive' WHERE user_id='$edit_id'";
        $update_res = mysqli_query($connection,$update_query);
        header("location:user_account.php");
     }else {
        $update_query = "UPDATE `users` SET `status`='Active' WHERE user_id='$edit_id'";
        $update_res = mysqli_query($connection,$update_query);
        header("location:user_account.php");
     }

  }



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/branch_styles.css" />
    <link rel="shortcut icon" href="img/casco_logo.png" type="img/png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
    <script src="assets/js/datatables.min.js"></script>
    <title>Casco | User Account</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/datatables.min.css">

    <script type="text/javascript">
      function delete_id(id)
       {  
        swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
       })
       .then((willDelete) => {
       if (willDelete) {
       window.location.href='user_account.php?delete_id='+id
       swal("Your file has been deleted!", {
       icon: "success",
       });
      } else {
       swal("Your data is safe!");
      }
     });
       }
   </script>

   <script type="text/javascript">
      function edit_id(id)
       {  
        swal({
          title: "Are you sure?",
          text: "Edit user status",
          icon: "warning",
          buttons: true,
          dangerMode: true,
       })
       .then((willDelete) => {
       if (willDelete) {
       window.location.href='user_account.php?edit_id='+id
       swal("Your file has been deleted!", {
       icon: "success",
       });
      } else {
       swal("Your data is safe!");
      }
     });
       }
   </script>

   <style>
       #Active {
         color: #09ad95;
         font-weight: bolder;
         font-size: 100%;
       }

       #Inactive {
         color: #f92649;
         font-weight: bolder;
         font-size: 100%;
       }
   </style>
</head>

<body>
    
<?php 
     
     $user_query = "SELECT * FROM `users` WHERE user_id='".$_SESSION['admin']."'";
     $user_result = mysqli_query($connection,$user_query);
 
     $user_row = mysqli_fetch_array($user_result);
  
     $user_type = $user_row['user_type'];
 
    if($user_type != 'Admin'){
     
       echo "<script type='text/javascript'>
            swal({
             title: 'This page is restricted! you will be redirected to home',
             icon: 'warning',
              })
              .then((willDelete) => {
             if (willDelete) {
                window.location='admin_dashboard.php'
              }
              });
            </script>";
 
     }  
     
     ?>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading py-2 primary-text fs-4 fw-bold border-bottom">
                <img src="img/casco_logo.png"width="60px">Casco
            </div>
            <div class="list-group list-group-flush my-1">
                <a href="admin_dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="inventory.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-database"></i> Stock Monitoring</a>
                <a href="product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-server"></i> Physical Monitoring</a>
                <a href="receiving.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-paperclip me-2"></i>Receiving</a>
                <a href="request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Request</a>
                <a href="scan_request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-qrcode"></i>  Scan Request</a>
                <a href="issuance.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-paperclip"></i> Issuance</a>
                <a href="add_product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-clipboard"></i> Add Product</a>
                <a href="history.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"> 
                         <i class="fas fa-history"></i> History of Transaction</a>
                <a href="scan_item.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-qrcode"></i> Scan an Item</a>
                <a href="branch.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-code-branch"></i> Branch</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
        
            <nav class="navbar navbar-expand-lg py-2 px-4">
               <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-5 me-3" id="menu-toggle"></i>
                    <h6 class="fs-5 m-0">User Account</h6>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Admin
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="manage_account.php">Manage Profile</a></li>
                                <li><a class="dropdown-item" href="user_account.php">User</a></li>
                                <li><a class="dropdown-item" href="logout.php?logout">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="tbl">
                     <div class="head">
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <a href="add_user.php" class="btn btn-primary">Add User</a>
                               </div>
                         </div>
                    </div>

                    <div class="row">
                      <div class="col-12">
                          <div class="data_table">
                              <table id="employee_data" class="table table-striped table-bordered">
                                  <thead>
                                     <tr>
                                         <th>Fullname</th>
                                         <th>User Type</th>
                                         <th>Username</th>
                                         <th>Status</th>
                                         <th>Action</th>
                                     </tr>
                                  </thead>
                                  <tbody>
                                       <?php while($row = mysqli_fetch_array($result)) { ?>
                                          <tr>
                                              <td><?php echo $row['name']; ?></td>
                                              <td><?php echo $row['user_type']; ?></td>
                                              <td><?php echo $row['username']; ?></td>
                                              <td id="<?php echo $row['status']; ?>"><?php echo $row['status']; ?></td>
                                              <td><div class="dropdown">
                                                   <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                                       Details
                                                   </button>
                                                   <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                       <li><a href="javascript:edit_id(<?php echo $row[0];?>)" class="dropdown-item editBtn">Edit Status</a></li>
                                                       <li><a data-bs-toggle="modal" data-bs-target="#update<?php echo $row[0]; ?>" class="dropdown-item editBtn">Update User Type </a></li>
                                                       <li><a href="javascript:delete_id(<?php echo $row[0];?>)" class="dropdown-item editBtn">Delete</a></li>
                                                   </ul>
                                                   </div>
                                                </td>
                                          </tr>
                                          <?php include 'update_usertype.php';  ?>
                                        <?php } ?>
                                  </tbody>
                             </table>
                         </div>
                     </div>
                 </div>
                
            </div>

            <!-- Modal start -->
               <div class="modal fade" id="import" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Import Product</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_add_branch.php" method="post">
                             <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Branch Name</label>
                                        <input type="text" class="form-control" name="branch_name" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Branch Manager</label>
                                        <input type="text" class="form-control" name="branch_manager" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Address</label>
                                        <input type="text" class="form-control" name="branch_address" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Contact No</label>
                                        <input type="text" class="form-control" name="contact_no" required>
                                    </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="submit" value="Save">
                              </div>
                          </form>
                     </div>
                 </div>
              </div>
            <!----modal end-->
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>

        <script>  
             $(document).ready(function(){  
             $('#employee_data').DataTable();  
            });  
        </script>
</body>

</html>
<?php
  session_start();
  // destroy session
  if(isset($_GET['logout']))
  {
    $_SESSION['admin']="";
     header("location:admin_dashboard.php");
     exit();
  }

?>
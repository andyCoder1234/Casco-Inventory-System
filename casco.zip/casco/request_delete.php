<?php

require 'connection.php';
require 'alert.php';

if(isset($_GET['request_delete_id']))
{   
    
    $product_id = $_GET['request_delete_id'];

    $query = "DELETE FROM `request_temp` WHERE product_id='$product_id'";
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

    echo "<script type='text/javascript'>
    swal({
       title: 'Product removed',
       icon: 'warning',
    })
     .then((willDelete) => {
     if (willDelete) {
       window.location='request.php'
       }
       });
     </script>";  
}

?>

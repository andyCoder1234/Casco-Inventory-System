<?php

  require 'connection.php';
  require 'alert.php';

  session_start();  
  $received_id = uniqid();
  @$received_id = $_SESSION['received_id'];

  if(isset($_POST['submit'])){
     
    $product_id = null;
  
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];

    $query = "SELECT product_id FROM products WHERE product_code='$product_name'";
    $result = mysqli_query($connection,$query) or die(mysqli_error($connection));
    while($row = mysqli_fetch_array($result)){
       $product_id = $row['product_id'];
    }

    if($product_id == ""){

       echo "<script type='text/javascript'>
                     swal({
                        title: 'Product not found',
                        icon: 'warning',
                     })
                      .then((willDelete) => {
                      if (willDelete) {
                        window.location='scan_item.php'
                        }
                        });
          </script>"; 
        
    }else if ($received_id == null){
      echo "<script type='text/javascript'>
      swal({
         title: 'Empty Received ID. Try again',
         icon: 'warning',
       })
       .then((willDelete) => {
       if (willDelete) {
          window.location='scanner_recieve_new.php'
        }
        });
     </script>";  
    }else {

       for($i = 0; $i < $quantity; $i++){

         $query = "INSERT INTO `receiving_temp`(`receiving_id`, `product_id` ,`received_id`) VALUES (null,'$product_id','$received_id')";
         $result = mysqli_query($connection,$query) or die(mysqli_error($connection));
       }
  
       header("location:scan_item.php");

    }

  } 

?>
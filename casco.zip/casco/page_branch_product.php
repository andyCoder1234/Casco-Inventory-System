<?php 

  session_start();
  require 'connection.php';
  if($_SESSION['branch'] == "") {
  header("location:index.php");
 }

   $branch_query = "SELECT * FROM `branch` WHERE branch_id='".$_SESSION['branch']."'";
   $branch_res = mysqli_query($connection,$branch_query);

   $branch_row = mysqli_fetch_array($branch_res);

  
  $query ="SELECT * FROM products ORDER BY product_id DESC";  
  $result = mysqli_query($connection, $query); 

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/inventory_style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
    <script src="assets/js/datatables.min.js"></script>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/datatables.min.css">

    <title>Casco | Admin Physical Monitoring</title>

    <script type="text/javascript">
      function delete_id(id)
       {  
        swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
       })
       .then((willDelete) => {
       if (willDelete) {
       window.location.href='product.php?delete_id='+id
       swal("Your file has been deleted!", {
       icon: "success",
       });
      } else {
       swal("Your data is safe!");
      }
     });
       }
   </script>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading py-2 primary-text fs-4 fw-bold border-bottom">
                <img src="img/casco_logo.png"width="60px">Casco
            </div>
            <div class="list-group list-group-flush my-1">
                <a href="page_branch_dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="page_branch_product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-server"></i> Physical Monitoring</a>
                <a href="page_branch_inventory.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Inventory</a>
                <a href="page_branch_issuance.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-paperclip"></i> Issuance Request</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
        
        <nav class="navbar navbar-expand-lg py-2 px-4">
               <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-5 me-3" id="menu-toggle"></i>
                    <h6 class="fs-5 m-0">Product List </h6>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="page_branch_logout.php?logout">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
            <!---table start-->

            <div class="tbl">
                <div class="row">
                     <div class="tbl-head">
                          <h5>Product List</h5>
                      </div>
                      <div class="col-12">
                          <div class="data_table">
                              <table id="employee_datas" class="table table-striped table-bordered">
                                  <thead>
                                     <tr>
                                         <th>Product Code</th>
                                         <th>Name</th>
                                         <th>Description</th>
                                         <th>Brand</th>
                                         <th>Supplier</th>
                                         <th>Price</th>
                                     </tr>
                                  </thead>
                                  <tbody>
                                       <?php while($row = mysqli_fetch_array($result)) { ?>
                                          <tr>
                                              <td><?php echo $row[1]; ?></td>
                                              <td><?php echo $row[2]; ?></td>
                                              <td><?php echo $row[3]; ?></td>
                                              <td><?php echo $row[4]; ?></td>
                                              <td><?php echo $row[5]; ?></td>
                                              <td><?php echo $row[6]; ?></td>
                                              
                                          </tr>
                                        <?php } ?>
                                  </tbody>
                             </table>
                         </div>
                     </div>
                 </div>
             </div>

            <!---table end-->
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>

        <!-- ============ Java Script Files  ================== -->

        <script>  
             $(document).ready(function(){  
             $('#employee_datas').DataTable();  
            });  
        </script>
   
    
</body>

</html>
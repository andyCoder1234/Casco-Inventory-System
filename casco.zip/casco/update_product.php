<!-- Modal start -->
<div class="modal fade" id="update<?php echo $row[0]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Update Product</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_update_product.php" method="post">
                             <input type="hidden" name="product_id" value="<?php echo $row[0]; ?>">
                             <div class="modal-body">
                                   <div class="mb-3">
                                        <label for="formFile" class="form-label">Product Code:</label>
                                        <input type="text" class="form-control" name="product_code" value="<?php echo $row[1]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Product Name:</label>
                                        <input type="text" class="form-control" name="product_name" value="<?php echo $row[2]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Description:</label>
                                        <input type="text" class="form-control" name="description" value="<?php echo $row[3]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Brand:</label>
                                        <input type="text" class="form-control" name="brand" value="<?php echo $row[4]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Supplier:</label>
                                        <input type="text" class="form-control" name="supplier" value="<?php echo $row[5]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Price:</label>
                                        <input type="number" class="form-control" name="price" value="<?php echo $row[6]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Cost:</label>
                                        <input type="number" class="form-control" name="cost" value="<?php echo $row[7]; ?>" required>
                                    </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="update" value="Update">
                              </div>
                          </form>
                     </div>
                 </div>
              </div>
            <!----modal end-->
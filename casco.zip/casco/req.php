<?php

 require 'connection.php';

 session_start();
 $request_id = uniqid();
 $_SESSION['request'] = $request_id;


header('Location: request.php');
?>
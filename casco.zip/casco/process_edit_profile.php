<?php

 require 'alert.php';
 require 'connection.php';

 if(isset($_POST['update_profile'])){

      $query = "UPDATE `users` SET `name`='".$_POST['name']."',`username`='".$_POST['username']."' WHERE user_id='".$_POST['user_id']."'";
      $result = mysqli_query($connection,$query);

      echo "<script type='text/javascript'>
      swal({
       title: 'Profile succesfully updated',
       icon: 'success',
      })
     .then((willDelete) => {
     if (willDelete) {
      window.location='manage_account.php'
     }
     });
    </script>";

 }


?>
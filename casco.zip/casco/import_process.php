<?php

    require 'connection.php';
    require 'alert.php';

    if(isset($_POST['import'])){
      
            $fileName = $_FILES["excel"]["name"];
			$fileExtension = explode('.', $fileName);
            $fileExtension = strtolower(end($fileExtension));
			$newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

			$targetDirectory = "uploads/" . $newFileName;
			move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory);

			error_reporting(0);
			ini_set('display_errors', 0);

			require 'excelReader/excel_reader2.php';
			require 'excelReader/SpreadsheetReader.php';

            if(!in_array($fileExtension, ['xlsx'])){
                echo "<script type='text/javascript'>
                      swal({
                        title: 'Unsupported file',
                        icon: 'error',
                      })
                      .then((willDelete) => {
                      if (willDelete) {
                        window.location='add_product.php'
                        }
                      });
                    </script>";       
       } else {
                $reader = new SpreadsheetReader($targetDirectory);
		    	foreach($reader as $key => $row){

				   $code = $row[0];
				   $name = $row[1];
				   $desc = $row[2];
                   $brand = $row[3];
                   $supplier = $row[4];
                   $price = $row[5];
                   $cost = $row[6];
                   

                   $import_query = "INSERT INTO `products`(`product_code`, `product_name`, `description`, `brand`, `supplier`, `price`, `cost`)
                                     VALUES ('$code','$name','$desc','$brand','$supplier','$price','$cost')";
                 
			            mysqli_query($connection,$import_query);

                   echo "<script type='text/javascript'>
                      swal({
                         title: 'Succesfully saved',
                         icon: 'success',
                      })
                       .then((willDelete) => {
                       if (willDelete) {
                         window.location='add_product.php'
                         }
                         });
                     </script>";  

		    	    }
         }
    }

    if(isset($_POST['submit'])){
    
       $add_product_query = "INSERT INTO `products`(`product_code`, `product_name`, `description`, `brand`, `supplier`, `price`, `cost`)
                              VALUES ('".$_POST['product_code']."','".$_POST['product_name']."','".$_POST['description']."','".$_POST['brand']."',
                              '".$_POST['supplier']."','".$_POST['price']."','".$_POST['cost']."')";

       mysqli_query($connection,$add_product_query);

       echo "<script type='text/javascript'>
             swal({
                title: 'Succesfully saved',
                 icon: 'success',
             })
              .then((willDelete) => {
              if (willDelete) {
                  window.location='add_product.php'
                }
               });
             </script>";  

    }

?>
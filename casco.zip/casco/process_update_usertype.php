<?php

  require 'connection.php';
  require 'alert.php';

  if(isset($_POST['update'])) {
    
      $query = "UPDATE `users` SET `user_type`='".$_POST['user_type']."' WHERE `user_id`='".$_POST['user_id']."'";
      $result = mysqli_query($connection,$query);

      echo "<script type='text/javascript'>
     swal({
       title: 'The Usertype has been updated successfully',
       icon: 'success',
     })
     .then((willDelete) => {
     if (willDelete) {
       window.location='user_account.php'
       }
       });
     </script>";  

  }

?>
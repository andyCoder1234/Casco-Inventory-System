<?php

 require 'connection.php';

 session_start();
 $received_id = uniqid();
 $_SESSION['received_id'] = $received_id;


header('Location: receiving.php');
?>
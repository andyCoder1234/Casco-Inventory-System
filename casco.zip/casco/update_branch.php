<!-- Modal start -->
<div class="modal fade" id="update<?php echo $row[0]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Update Branch</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_update_branch.php" method="post">
                             <input type="hidden" name="branch_id" value="<?php echo $row[0]; ?>">
                             <div class="modal-body">
                                   <div class="mb-3">
                                        <label for="formFile" class="form-label">Branch Name</label>
                                        <input type="text" class="form-control" name="branch_name" value="<?php echo $row[2]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Branch Manager</label>
                                        <input type="text" class="form-control" name="branch_manager" value="<?php echo $row[1]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Address</label>
                                        <input type="text" class="form-control" name="branch_address" value="<?php echo $row[3]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Contact No</label>
                                        <input type="text" class="form-control" name="contact_no" value="<?php echo $row[4]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Username</label>
                                        <input type="text" class="form-control" name="username" value="<?php echo $row[5]; ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Password</label>
                                        <input type="text" class="form-control" name="branch_password" value="<?php echo $row[6]; ?>" required>
                                    </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="update" value="Update">
                              </div>
                          </form>
                     </div>
                 </div>
              </div>
            <!----modal end-->
<?php

 require 'connection.php';

  session_start();
  
  if($_SESSION['admin'] == "") {
    header("location:index.php");
  }
  $request_id = uniqid();
  $_SESSION['request'] = $request_id;

  $query = "DELETE FROM inventory_temp;";
  $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

  $query = "INSERT INTO inventory_temp (inventory_temp_id, product_id, request_id) SELECT null, product_id, '".$request_id."' FROM inventory";
  $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

  header('Location: issuance.php');

?>
<?php  

   session_start();
   require 'connection.php';
   if($_SESSION['admin'] == "") {
    header("location:index.php");
   }
  include 'alert.php';

  if(isset($_GET['transaction_id'])){

      $id = $_GET['transaction_id'];

      $query = "SELECT * FROM `history` WHERE req_rec_id='$id'";
      $result = mysqli_query($connection,$query);
      
      $row = mysqli_fetch_array($result);

      $branch_id = $row['destanation_id'];
      $transaction = $row['req_rec_id'];

      $branch_query = "SELECT `branch_name` FROM `branch` WHERE branch_id='$branch_id'";
      $branch_result = mysqli_query($connection,$branch_query);

      $branch_name = mysqli_fetch_array($branch_result);

      if($branch_name == null){
        $br_name = 'Warehouse';
      }else {
        $br_name = $branch_name['branch_name']; 
      }

      if($branch_id > 0){

        $query1 ="SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM requested_items r INNER JOIN products p ON p.product_id = r.product_id WHERE request_id = '".$id."' GROUP BY r.product_id";  
        $result1 = mysqli_query($connection, $query1);

      }else {
        $query1 ="SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM inventory_temp r INNER JOIN products p ON p.product_id = r.product_id WHERE received_id = '".$id."' GROUP BY r.product_id";  
        $result1 = mysqli_query($connection, $query1);
      }
  

  }
  
   
 ?> 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/issuance_req__style.css" />
    <link rel="shortcut icon" href="img/casco_logo.png" type="img/png">
    <!--bootstrap css file-->
    <link rel="stylesheet" href="css/boxicons.min.css">
    <script src="js/sweetalert.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
    <script src="assets/js/datatables.min.js"></script>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/datatables.min.css">
    <title>Casco | Admin Issuance Request</title>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading py-2 primary-text fs-4 fw-bold border-bottom">
                <img src="img/casco_logo.png"width="60px">Casco
            </div>
            <div class="list-group list-group-flush my-1">
                <a href="admin_dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="inventory.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-database"></i> Stock Monitoring</a>
                <a href="product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-server"></i> Physical Monitoring</a>
                <a href="receiving.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-paperclip me-2"></i>Receiving</a>
                <a href="request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Request</a>
                <a href="scan_request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-qrcode"></i>  Scan Request</a>
                <a href="issuance.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-paperclip"></i> Issuance</a>
                <a href="add_product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-clipboard"></i> Add Product</a>
                <a href="history.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"> 
                         <i class="fas fa-history"></i> History of Transaction</a>
                <a href="scan_item.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-qrcode"></i> Scan an Item</a>
                <a href="branch.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-code-branch"></i> Branch</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
        
            <nav class="navbar navbar-expand-lg py-2 px-4">
               <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-5 me-3" id="menu-toggle"></i>
                    <h6 class="fs-5 m-0">History Details</h6>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Admin
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="manage_account.php">Manage Profile</a></li>
                                <li><a class="dropdown-item" href="user_account.php">User</a></li>
                                <li><a class="dropdown-item" href="logout.php?logout">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="container">
            
                 <div class="frm-issuance">
                       <div class="tbl-head">
                          <h5>Issuance Details</h5>
                      </div>
                       
                           <div class="row">
                               <div class="col-12">   
                                   <label for="formFile" class="form-label">Transaction Id:</label>
                                   <input type="text" class="form-control" name="issued_by" value="<?php echo $row['req_rec_id']; ?>" readonly>
                               </div>
                               <div class="col-12">   
                                   <label for="formFile" class="form-label">To:</label>
                                   <input type="text" class="form-control" name="received_by" value="<?php echo $br_name; ?>" readonly>
                               </div>
                               <div class="col-12">   
                                   <label for="formFile" class="form-label">Date:</label>
                                   <input type="text" class="form-control" name="approved_by" value="<?php echo $row['history_date']; ?>" readonly>
                                </div>
                                <div class="col-12 pt-2">   
                                   <a href="print_transaction.php?transaction_no=<?php echo $row['req_rec_id']; ?>" class="btn btn-secondary">Print</a>
                                </div>
                            </div>
                     

                 </div>

                 <div class="tbl"> 
                
                  <div class="row">
                       <div class="tbl-head">
                          <h5>Issued Items</h5>
                      </div>
                    <div class="box">
                        <div class="data_table">  
                            <table id="employee_data" class="table table-striped table-bordered">  
                                <thead>  
                                   <tr>  
                                     <th>Product Code</th>
                                     <th>Product Name</th>
                                     <th>Supplier</th>
                                     <th>Price</th>
                                     <th>Cost</th>
                                     <th>Quantity</th>
                                   </tr>
                                </thead>  
                                 <?php while($row = mysqli_fetch_array($result1)) { ?>
                                   <tr>
                                       <td><?php echo $row['product_code'] ?></td>
                                       <td><?php echo $row['product_name'] ?></td>
                                       <td><?php echo $row['supplier'] ?></td>
                                       <td><?php echo $row['price'] ?></td>
                                       <td><?php echo $row['cost'] ?></td>
                                       <td><?php echo $row['COUNT(*)'] ?></td>
                                   </tr>

                                 <?php } ?>
                          </table>  
                        </div> 
                    </div>
                
                </div>
             
             </div>  



           </div>

        
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>

    <script>  
      $(document).ready(function(){  
        $('#employee_data').DataTable();  
      });  
     </script>
</body>

</html>
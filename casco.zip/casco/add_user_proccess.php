<?php

  include 'alert.php';
  require_once('connection.php');

  $error_msg = null;
  $alert = null;

  $name = null;
  $username = null;
  $user_pass = null;

  if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $user_type = $_POST['user_type'];
    $username = $_POST['username'];
    $user_pass = $_POST['user_pass'];
    $confirm_user_pass = $_POST['confirm_user_pass'];

    $hash_password = password_hash($confirm_user_pass, PASSWORD_DEFAULT);

    $user_query = "SELECT * FROM `users` WHERE username='$username' OR user_pass='$hash_password'";
    $user_result = mysqli_query($connection,$user_query);

    $user_row = mysqli_fetch_array($user_result);

    $name_query = "SELECT * FROM `users` WHERE name='$name'";
    $name_result = mysqli_query($connection,$name_query);

    $name_row = mysqli_fetch_array($name_result);


    if($user_row > 0){

        $error_msg = "*Username or Password already exist";
        $alert = "alert-danger";

    }else if($user_pass != $confirm_user_pass){

        $error_msg = "*Password not match";
        $alert = "alert-danger";

    }else if($name_row > 0){

        $error_msg = "*Full Name already exist";
        $alert = "alert-danger";
        $name = null;

    }else {

        $query = "INSERT INTO `users`(`name`, `username`, `user_pass`, `user_type`, `status`)
                  VALUES ('$name','$username','$hash_password','$user_type','Active')";
        $result = mysqli_query($connection,$query);

        echo "<script type='text/javascript'>
               swal({
                 title: 'Succesfully Saved',
                  icon: 'success',
              })
              .then((willDelete) => {
                if (willDelete) {
                   window.location='user_account.php'
                 }
             });
        </script>";

    }

  }

?>
<?php 

  require 'connection.php';
  require 'alert.php';

  if(isset($_POST['submit'])){

    $name_query = "SELECT * FROM `branch` WHERE branch_name='".$_POST['branch_name']."'";
    $name_result = mysqli_query($connection,$name_query);

    $name_row = mysqli_fetch_array($name_result);

    $user_query = "SELECT * FROM `branch` WHERE username='".$_POST['username']."' OR branch_password='".$_POST['branch_password']."'";
    $user_result = mysqli_query($connection,$user_query);

    $user_row = mysqli_fetch_array($user_result);

    if($name_row > 0){

      echo "<script type='text/javascript'>
                      swal({
                         title: 'Branch Name already exist',
                         icon: 'warning',
                      })
                       .then((willDelete) => {
                       if (willDelete) {
                         window.location='branch.php'
                         }
                         });
            </script>";  

    }else if($user_row > 0){

      echo "<script type='text/javascript'>
      swal({
         title: 'Username or password already exist',
         icon: 'warning',
      })
       .then((willDelete) => {
       if (willDelete) {
         window.location='branch.php'
         }
         });
       </script>";  


    }else {

      $query = "INSERT INTO `branch`(`branch_manager`, `branch_name`, `branch_address`, `contact_no`, `username`, `branch_password`, `status`) 
                          VALUES ('".$_POST['branch_manager']."','".$_POST['branch_name']."','".$_POST['branch_address']."','".$_POST['contact_no']."',
                                 '".$_POST['username']."','".$_POST['branch_password']."','Active')";

    mysqli_query($connection,$query);

    echo "<script type='text/javascript'>
                      swal({
                         title: 'Succesfully saved',
                         icon: 'success',
                      })
                       .then((willDelete) => {
                       if (willDelete) {
                         window.location='branch.php'
                         }
                         });
            </script>";  

    }

  }

?>
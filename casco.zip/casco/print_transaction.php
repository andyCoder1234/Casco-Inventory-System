<?php
require('fpdf185/fpdf.php');

require_once('connection.php');


class PDF extends FPDF {
	function head($connection){

        if(isset($_GET['transaction_no'])){

            $id = $_GET['transaction_no'];
        
            $query = "SELECT * FROM `history` WHERE req_rec_id='$id'";
            $result = mysqli_query($connection,$query);
        
            $row = mysqli_fetch_array($result);
            $history_date = $row['history_date'];
        
            $branch_id = $row['destanation_id'];
            $transaction = $row['req_rec_id'];
        
            $branch_query = "SELECT `branch_name` FROM `branch` WHERE branch_id='$branch_id'";
            $branch_result = mysqli_query($connection,$branch_query);
        
            $branch_name = mysqli_fetch_array($branch_result);
        
           if($branch_name == null){
             $br_name = 'Warehouse';
            }else {
            $br_name = $branch_name['branch_name']; 
           }
        
         }

        $this->Image('img/casco_logo.png',68,7,13);
        $this->SetFont('Times','IU',12);
        $this->Cell(200,1,$br_name,0,0,'C');
        $this->Ln();
        $this->SetFont('Times','IU',12);
        $this->Cell(200,10,'Transaction No: '.$transaction,0,0,'C');
        $this->Ln();
        $this->SetFont('Times','IU',12);
        $this->Cell(325,8,'Date No: '.$history_date,0,0,'C');
        $this->Ln();
		
	}
	function Footer(){
		
		//Go to 1.5 cm from bottom
		$this->SetY(-15);
				
		$this->SetFont('Arial','',8);
		
		//width = 0 means the cell is extended up to the right margin
		$this->Cell(0,10,'Page '.$this->PageNo()." / {pages}",0,0,'C');
	}

        function headerTable(){
                $this->SetFont('Times','B',9);
                $this->Cell(25,7,'Product Code',1,0,'C');
                $this->Cell(53,7,'Name',1,0,'C');
                $this->Cell(50,7,'Supplier',1,0,'C');
                $this->Cell(15,7,'Price',1,0,'C');
                $this->Cell(15,7,'Cost',1,0,'C');
                $this->Cell(15,7,'Quantity',1,0,'C');
                $this->Cell(17,7,'Total Cost',1,0,'C');
                $this->Ln();
            }

        function viewTable($connection){

            if(isset($_GET['transaction_no'])){

                $id = $_GET['transaction_no'];
            
                $query = "SELECT * FROM `history` WHERE req_rec_id='$id'";
                $result = mysqli_query($connection,$query);
            
                $row = mysqli_fetch_array($result);
                $history_date = $row['history_date'];
            
                $branch_id = $row['destanation_id'];
                $transaction = $row['req_rec_id'];
            
                $branch_query = "SELECT `branch_name` FROM `branch` WHERE branch_id='$branch_id'";
                $branch_result = mysqli_query($connection,$branch_query);
            
                $branch_name = mysqli_fetch_array($branch_result);
            
               if($branch_name == null){
                 $br_name = 'Warehouse';
                }else {
                $br_name = $branch_name['branch_name']; 
               }

               if($branch_id > 0){

                $query1 ="SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM requested_items r INNER JOIN products p ON p.product_id = r.product_id WHERE request_id = '".$id."' GROUP BY r.product_id";  
                $result1 = mysqli_query($connection, $query1);
        
              }else {
                $query1 ="SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM inventory_temp r INNER JOIN products p ON p.product_id = r.product_id WHERE received_id = '".$id."' GROUP BY r.product_id";  
                $result1 = mysqli_query($connection, $query1);
              }

               while($row_tbl = mysqli_fetch_array($result1)){

                $this->SetFont('Times','B',7);
                $this->Cell(25,7,$row_tbl['product_code'],1,0,'C');
                $this->Cell(53,7,$row_tbl['product_name'],1,0,'C');
                $this->Cell(50,7,$row_tbl['supplier'],1,0,'C');
                $this->Cell(15,7,$row_tbl['price'],1,0,'C');
                $this->Cell(15,7,$row_tbl['cost'],1,0,'C');
                $this->Cell(15,7,$row_tbl['COUNT(*)'],1,0,'C');
                $this->Cell(17,7,$row_tbl['price'] * $row_tbl['COUNT(*)'],1,0,'C');
                $this->Ln();
                
               }
            
             }      
                
        }
}


//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm

$pdf = new PDF('P','mm','A4'); //use new class

//define new alias for total page numbers
$pdf->AliasNbPages('{pages}');

$pdf->AddPage();

//Image( file name , x position , y position , width [optional] , height [optional] )
// $pdf->Image('watermark.png',10,10,189);

//set font to arial, bold, 14pt
$pdf->SetFont('Arial','',12);
$pdf->head($connection);
$pdf->headerTable();
$pdf->viewTable($connection);


$pdf->Output();
?>

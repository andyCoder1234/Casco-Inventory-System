<?php 

$connection=mysqli_connect('127.0.0.1','root','','casco_db');

if(!$connection){
 die('Please check your connection'.mysqli_error());
}

?>
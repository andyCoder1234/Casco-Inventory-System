<?php

  require 'connection.php';
  require 'alert.php';
  
     session_start();
     $product_id = $_POST['product_id'];
     $product_name = $_POST['product_name'];
     $quantity = $_POST['quantity'];
     @$request_id = $_SESSION['request'];
  if(isset($_POST['submit'])){

   if($request_id == null){

      echo "<script type='text/javascript'>
      swal({
         title: 'Empty Request try again',
         icon: 'warning',
      })
       .then((willDelete) => {
       if (willDelete) {
         window.location='req.php'
         }
         });
      </script>";  


   }else {

      for($i=0; $i < $quantity; $i++){
         $query ="INSERT INTO `request_temp`(`request_temp_id`, `request_id`, `product_id`) VALUES ( null, '".$request_id."', '".$product_id."')";
         $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
     }
 
     echo "<script type='text/javascript'>
                          swal({
                             title: 'The product has been added successfully',
                             icon: 'success',
                          })
                           .then((willDelete) => {
                           if (willDelete) {
                             window.location='request.php'
                             }
                             });
               </script>";  

   }




  }
?>
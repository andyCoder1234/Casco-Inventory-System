 <div class="modal fade" id="confirm_receive" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
               <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Add to inventory</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_confirm_receive_process.php" method="post">
                             <div class="modal-body">
                                  <div class="table-responsive">
                                      <table class="table display">
                                          <tr class="fs-6">
                                             <th>Product Code</th>
                                             <th>Name</th>
                                             <th>Price</th>
                                             <th>Quantity</th>
                                          </tr>
                                          <?php 
                                            $product_query = "SELECT r.product_id, product_code, product_name, price, COUNT(*) FROM receiving_temp r INNER JOIN products p ON p.product_id  = r.product_id  GROUP BY r.product_id";
                                            $product_result = mysqli_query($connection,$product_query) or die($connection);
                                           while ($row = mysqli_fetch_assoc($product_result)) { ?>
                                              <tr class="fs-6 ">
                                                  <td><?php echo $row['product_code']; ?></td>
                                                  <td><?php echo $row['product_name']; ?></td>
                                                  <td><?php echo $row['price']; ?></td>
                                                  <td><?php echo $row['COUNT(*)']; ?></td>
                                              </tr>
                                           <?php } ?>
                                      </table>
                                  </div>
                                  <div class="row">
                                     <div class="col-md-6">

                                      </div>
                                     <div class="col-md-6">
                                         <label for="product_receiver" class="form-label">Received by :</label>
                                         <input type="text" class="form-control" id="product_receiver" name="product_receiver" required>
                                     </div>
                                  </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="submit" value="Confirm">
                              </div>
                          </form>
               </div>
       </div>
 </div>
<!----modal end-->

<div class="modal fade" id="confirm_request" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
               <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Finalize your request</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_request.php" method="post">
                             <div class="modal-body">
                                  <div class="table-responsive">
                                      <table class="table display">
                                          <tr class="fs-6">
                                             <th>Product Code</th>
                                             <th>Name</th>
                                             <th>Price</th>
                                             <th>Quantity</th>
                                          </tr>
                                          <?php 
                                           $product_query = "SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM request_temp r INNER JOIN products p ON p.product_id  = r.product_id  GROUP BY r.product_id";
                                           $product_result = mysqli_query($connection,$product_query) or die($connection);
                                           while ($row = mysqli_fetch_assoc($product_result)) { ?>
                                              <tr class="fs-6 ">
                                                  <td><?php echo $row['product_code']; ?></td>
                                                  <td><?php echo $row['product_name']; ?></td>
                                                  <td><?php echo $row['price']; ?></td>
                                                  <td><?php echo $row['COUNT(*)']; ?></td>
                                              </tr>
                                           <?php } ?>
                                      </table>
                                  </div>
                                  <div class="row">
                                     <div class="col-md-6">

                                      </div>
                                     <div class="col-md-6">
                                         <label for="product_receiver" class="form-label">Requested by :</label>
                                         <input type="text" list="product_list" class="form-control" id="product_receiver" name="requestee" required>
                                         <datalist id="product_list">
                                           <?php 
                                              $query = 'SELECT branch_id, branch_name from branch';
                                              $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
                                               foreach($result as $row){
                                                 echo "<option value='".$row['branch_name']."'> ".$row['branch_name']."</option>";
                                              }
                                           ?>
                                        </datalist>
                                     </div>
                                  </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="submit" value="Confirm">
                              </div>
                          </form>
               </div>
       </div>
 </div>


 <div class="modal fade" id="confirm_scan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
               <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Add to inventory</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_confirm_scan_process.php" method="post">
                             <div class="modal-body">
                                  <div class="table-responsive">
                                      <table class="table display">
                                          <tr class="fs-6">
                                             <th>Product Code</th>
                                             <th>Name</th>
                                             <th>Price</th>
                                             <th>Quantity</th>
                                          </tr>
                                          <?php 
                                            $product_query = "SELECT r.product_id, product_code, product_name, price, COUNT(*) FROM receiving_temp r INNER JOIN products p ON p.product_id  = r.product_id  GROUP BY r.product_id";
                                            $product_result = mysqli_query($connection,$product_query) or die($connection);
                                           while ($row = mysqli_fetch_assoc($product_result)) { ?>
                                              <tr class="fs-6 ">
                                                  <td><?php echo $row['product_code']; ?></td>
                                                  <td><?php echo $row['product_name']; ?></td>
                                                  <td><?php echo $row['price']; ?></td>
                                                  <td><?php echo $row['COUNT(*)']; ?></td>
                                              </tr>
                                           <?php } ?>
                                      </table>
                                  </div>
                                  <div class="row">
                                     <div class="col-md-6">

                                      </div>
                                     <div class="col-md-6">
                                         <label for="product_receiver" class="form-label">Received by :</label>
                                         <input type="text" class="form-control" id="product_receiver" name="product_receiver" required>
                                     </div>
                                  </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="submit" value="Confirm">
                              </div>
                          </form>
               </div>
       </div>
 </div>


 <div class="modal fade" id="confirm_scan_request" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
               <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Finalize your request</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_confirm_scan_request_process.php" method="post">
                             <div class="modal-body">
                                  <div class="table-responsive">
                                      <table class="table display">
                                          <tr class="fs-6">
                                             <th>Product Code</th>
                                             <th>Name</th>
                                             <th>Price</th>
                                             <th>Quantity</th>
                                          </tr>
                                          <?php 
                                            $product_query = "SELECT r.product_id, product_code, product_name, description, brand, supplier, price, cost, COUNT(*) FROM request_temp r INNER JOIN products p ON p.product_id  = r.product_id  GROUP BY r.product_id";
                                            $product_result = mysqli_query($connection,$product_query) or die($connection);
                                           while ($row = mysqli_fetch_assoc($product_result)) { ?>
                                              <tr class="fs-6 ">
                                                  <td><?php echo $row['product_code']; ?></td>
                                                  <td><?php echo $row['product_name']; ?></td>
                                                  <td><?php echo $row['price']; ?></td>
                                                  <td><?php echo $row['COUNT(*)']; ?></td>
                                              </tr>
                                           <?php } ?>
                                      </table>
                                  </div>
                                  <div class="row">
                                     <div class="col-md-6">

                                      </div>
                                     <div class="col-md-6">
                                         <label for="product_receiver" class="form-label">Received by :</label>
                                         <input type="text" list="branch_list" class="form-control" id="product_receiver" name="requestee" required>
                                         <datalist id="branch_list">
                                           <?php 
                                              $bquery = 'SELECT branch_id, branch_name from branch';
                                              $bresult = mysqli_query($connection, $bquery) or die(mysqli_error($connection));
                                               foreach($bresult as $row){
                                                 echo "<option value='".$row['branch_name']."'> ".$row['branch_name']."</option>";
                                              }
                                           ?>
                                        </datalist>
                                     </div>
                                  </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="submit" value="Confirm">
                              </div>
                          </form>
               </div>
       </div>
 </div>




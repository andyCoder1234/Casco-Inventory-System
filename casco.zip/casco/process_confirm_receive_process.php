<?php 

 require 'connection.php';
 require 'alert.php';

  session_start();
  @$received_id = $_SESSION['received_id'];

 if(isset($_POST['submit'])){

     $receive_temp_query = "SELECT * FROM `receiving_temp`";
     $receive_temp_res = mysqli_query($connection,$receive_temp_query) or die(mysqli_error($connection));
     $receive_temp_num = mysqli_num_rows($receive_temp_res);

     if($receive_temp_num <= 0){
       
        echo "<script type='text/javascript'>
                      swal({
                         title: 'No product is selected',
                         icon: 'warning',
                      })
                       .then((willDelete) => {
                       if (willDelete) {
                         window.location='receiving.php'
                         }
                         });
           </script>";

     }else {

        $product_receiver = $_POST['product_receiver'];
        $inventory_insert_query = "INSERT INTO inventory (inventory_id, product_id, product_receiver) SELECT null, product_id, '$product_receiver' FROM receiving_temp";
        $inventory_insert_result = mysqli_query($connection,$inventory_insert_query) or die(mysqli_error($connection));
         
        $query = 'INSERT INTO inventory_temp (product_id, received_id) SELECT product_id, received_id FROM receiving_temp WHERE received_id = "'.$received_id.'"; ';
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

        $query = "INSERT INTO `history`(`destanation_id`, `req_rec_id`, `title`, `subject`)
                                VALUES (0,'$received_id','Warehouse','Add Product')";
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

        $del_query = 'DELETE FROM receiving_temp';
        $del_result = mysqli_query($connection, $del_query) or die(mysqli_error($connection));

        unset($_SESSION['received_id']);

        $received_id = uniqid();
        $_SESSION['received_id'] = $received_id;

        echo "<script type='text/javascript'>
        swal({
           title: 'The following products has been added to the inventory',
           icon: 'success',
        })
         .then((willDelete) => {
         if (willDelete) {
           window.location='inventory.php'
           }
           });
         </script>";

         
     }

 }

?>
<?php 

  session_start();
  require 'connection.php';
  if($_SESSION['branch'] == "") {
  header("location:index.php");
 }

 include 'alert.php';
   
   $branch_query = "SELECT * FROM `branch` WHERE branch_id='".$_SESSION['branch']."'";
   $branch_res = mysqli_query($connection,$branch_query);

   $branch_row = mysqli_fetch_array($branch_res);

   if(isset($_GET['product_detail_id'])){

    $id = $_GET['product_detail_id'];

    $query = "SELECT * FROM `products` WHERE `product_id`='$id'";
    $result = mysqli_query($connection,$query);

    $row = mysqli_fetch_array($result);

     $query2 = 'SELECT product_id, COUNT(*) FROM branch_inventory WHERE product_id="'.$id.'" AND branch_id="'.$_SESSION['branch'].'" GROUP BY product_id;';
     $result2 = mysqli_query($connection, $query2) or die (mysqli_error($connection));
     if (mysqli_num_rows($result2) <= 0)
      {
        $product_quantity = 0;
      } else {
       while ($row2 = mysqli_fetch_assoc($result2)) {
         $product_quantity = $row2['COUNT(*)'];
      }
 }
     

}

if(isset($_GET['delete_id'])){

    $del_id = $_GET['delete_id'];
    
    $del_query = "DELETE FROM `branch_inventory` WHERE branch_inventory_id='$del_id'";
    $del_result = mysqli_query($connection,$del_query);

    header("location:page_branch_inventory.php");

 }

   
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/product_details.css" />
    <link rel="shortcut icon" href="img/casco_logo.png" type="img/png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
    <script src="assets/js/datatables.min.js"></script>
    <title>Casco | Branch Inventory</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/datatables.min.css">
    <script type="text/javascript">
      function delete_id(id)
       {  
        swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
       })
       .then((willDelete) => {
       if (willDelete) {
       window.location.href='page_branch_product_details.php?delete_id='+id
       swal("Your file has been deleted!", {
       icon: "success",
       });
      } else {
       swal("Your data is safe!");
      }
     });
       }
   </script>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading py-2 primary-text fs-4 fw-bold border-bottom">
                <img src="img/casco_logo.png"width="60px">Casco
            </div>
            <div class="list-group list-group-flush my-1">        
                <a href="page_branch_dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="page_branch_product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-server"></i> Physical Monitoring</a>
                <a href="page_branch_inventory.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Inventory</a>
                <a href="page_branch_issuance.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-paperclip"></i> Issuance Request</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
        
            <nav class="navbar navbar-expand-lg py-2 px-4">
               <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-5 me-3" id="menu-toggle"></i>
                    <h6 class="fs-5 m-0">Product Information </h6>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="page_branch_logout.php?logout">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

        
            <div class="container">
                 <div class="box-1">
                      <div class="head">
                           <h5>Product Details</h5>
                      </div>
                      <div class="body">
                           <p>Product Code : <span><?php echo $row['product_code']; ?></span></p>
                           <p>Product Name : <span><?php echo $row['product_name']; ?></span></p>
                           <p>Category : <span><?php echo $row['description']; ?></span></p>
                           <p>Brand : <span><?php echo $row['brand']; ?></span></p>
                           <p>Supplier : <span><?php echo $row['supplier']; ?></span></p>
                           <p>Price : <span><?php echo $row['price']; ?></span></p>
                           <p>Quantity : <span><?php echo $product_quantity; ?></span></p>
                      </div> 
                 </div>
                 <div class="box-2">
                      <div class="head">
                           <h5>Inventory</h5>
                      </div>
                     <?php
                        $i = 1;
                        $inventory_query = "SELECT * FROM `branch_inventory` WHERE product_id='$id' AND branch_id='".$_SESSION['branch']."'";
                        $inventory_result = mysqli_query($connection,$inventory_query);       
                          
                     ?>
                     <table>
                          <tr>
                             <th>No</th>
                             <th>Action</th>
                          </tr>
                          <?php while($inventory_row = mysqli_fetch_array($inventory_result)) { ?>
                              <tr>
                                 <td><?php echo $i++; ?></td>
                                 <td><a href="javascript:delete_id(<?php echo $inventory_row['branch_inventory_id'];?>)" class="btn btn-danger" type="button">Delete</a></td>
                              </tr>
                          <?php } ?>
                        
                     </table>
                 </div>
             </div> 

        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>

       <script>  
             $(document).ready(function(){  
             $('#employee_data').DataTable();  
            });  
        </script>
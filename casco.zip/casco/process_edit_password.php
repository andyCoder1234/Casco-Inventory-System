<?php 

 require 'alert.php';
 require 'connection.php';

 $host = "127.0.0.1";  
 $username = "root";  
 $password = "";  
 $database = "casco_db";

 $pdo = new PDO("mysql:host=$host; dbname=$database", $username, $password); 

 if(isset($_POST['update_password'])){
     
         $id = $_POST['user_id'];
         $user = $_POST['username'];
         $old_pass = $_POST['password'];
         $new_pass = $_POST['new_password'];
         $con_pass = $_POST['con_password'];

         $hash_password = password_hash($con_pass, PASSWORD_DEFAULT);

         $sql = "SELECT * FROM `users` WHERE username = ?";
         $result = $pdo->prepare($sql);
         $result->bindParam(1, $user);
         $result->execute();

         $acc_rec = $result->fetch();

         if(!@password_verify($old_pass, $acc_rec['user_pass'])){

            echo "<script type='text/javascript'>
            swal({
             title: 'Incorrect password',
             icon: 'warning',
            })
           .then((willDelete) => {
           if (willDelete) {
            window.location='manage_account.php'
           }
           });
          </script>";
         }else {
            if($new_pass != $con_pass){

                echo "<script type='text/javascript'>
                 swal({
                     title: 'Password not match',
                       icon: 'warning',
                   })
                  .then((willDelete) => {
                    if (willDelete) {
                   window.location='manage_account.php'
                    }
                   });
                  </script>";
                
            }else {
                $query = "UPDATE `users` SET `user_pass`= '$hash_password' WHERE `user_id`='$id'";
                $result = mysqli_query($connection,$query);
                echo "<script type='text/javascript'>
                 swal({
                     title: 'Password succesfully change',
                       icon: 'success',
                   })
                  .then((willDelete) => {
                    if (willDelete) {
                   window.location='logout.php?logout'
                    }
                   });
                  </script>";
            }
         }


 }

?>
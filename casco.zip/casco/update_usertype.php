<!-- Modal start -->
<div class="modal fade" id="update<?php echo $row[0]; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Update Branch</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="process_update_usertype.php" method="post">
                             <input type="hidden" name="user_id" value="<?php echo $row[0]; ?>">
                             <div class="modal-body">
                                   <div class="mb-3">
                                      <div class="form-group">
                                        <label for="usr">User Type:</label>
                                         <select class="form-control form-select-sm-6" aria-label=".form-select-sm example" id="sel2" name="user_type" required>
                                             <option><?php echo $row['user_type']; ?></option>
                                             <option>Admin</option>
                                             <option>Inventory Specialist</option>
                                             <option>Manager</option>
                                             <option>Staff</option>
                                             <option>Cashier</option>
                                          </select>
                                       </div>
                                    </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="update" value="Update">
                              </div>
                          </form>
                     </div>
                 </div>
              </div>
            <!----modal end-->
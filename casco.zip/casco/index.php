<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/index_style.css">
    <title>Sign In</title>
</head>
<body>
     <div class="wrapper">
         <div class="form-login">
              <div class="header">
                    <img src="img/casco_logo.png" width="150px" height="150px">
              </div>
              <div class="title">
                    <h3>Login</h3>
              </div>
              <form action="sign_in_proccess.php" method="post">
                    
                    <div class="row">
                       <div class="col-lg-12 col-sm-12">
                           <div class="form-group">
                               <label class="form-label" for="username">Username:</label>
                               <input class="form-control" type="text" id="username" name="username" required>
                          </div>
                       </div>
                       <div class="col-lg-12 col-md-12">
                           <div class="form-group">
                               <label class="form-label" for="password">Password:</label>
                               <input class="form-control" type="password" id="password" name="password" required>
                          </div>
                       </div>
                    </div>

                    <div class="row">
                         <div class="col-lg-12">
                              <input type="submit" class="btn btn-primary" name="submit" value="Login">
                         </div>
                    </div>
              </form> 
         </div>
     </div>
</body>
</html>
<?php 

session_start();
require 'connection.php';
if($_SESSION['admin'] == "") {
header("location:index.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="css/add_product_styles.css" />
    <link rel="shortcut icon" href="img/casco_logo.png" type="img/png">
    <!--bootstrap css file-->
    <link rel="stylesheet" href="css/boxicons.min.css">
    <script src="js/sweetalert.min.js"></script>
    <title>Casco | Admin Add Product</title>
</head>

<body>
<?php 
     
     $user_query = "SELECT * FROM `users` WHERE user_id='".$_SESSION['admin']."'";
     $user_result = mysqli_query($connection,$user_query);
 
     $user_row = mysqli_fetch_array($user_result);
  
     $user_type = $user_row['user_type'];
 
    if($user_type != 'Admin' && $user_type != 'Inventory Specialist'){
     
       echo "<script type='text/javascript'>
            swal({
             title: 'This page is restricted! you will be redirected to home',
             icon: 'warning',
              })
              .then((willDelete) => {
             if (willDelete) {
                window.location='admin_dashboard.php'
              }
              });
            </script>";
 
     }  
     
     ?>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading py-2 primary-text fs-4 fw-bold border-bottom">
                <img src="img/casco_logo.png"width="60px">Casco
            </div>
            <div class="list-group list-group-flush my-1">
                <a href="admin_dashboard.php" class="list-group-item list-group-item-action bg-transparent second-text active"><i
                        class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                <a href="inventory.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-database"></i> Stock Monitoring</a>
                <a href="product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-solid fa-server"></i> Physical Monitoring</a>
                <a href="receiving.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-paperclip me-2"></i>Receiving</a>
                <a href="request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-shopping-cart me-2"></i>Request</a>
                <a href="scan_request.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        class="fas fa-qrcode"></i>  Scan Request</a>
                <a href="issuance.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-paperclip"></i> Issuance</a>
                <a href="add_product.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-solid fa-clipboard"></i> Add Product</a>
                <a href="history.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold"> 
                         <i class="fas fa-history"></i> History of Transaction</a>
                <a href="scan_item.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         <i class="fas fa-qrcode"></i> Scan an Item</a>
                <a href="branch.php" class="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                        <i class="fas fa-code-branch"></i> Branch</a>
            </div>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
        
            <nav class="navbar navbar-expand-lg py-2 px-4">
               <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-5 me-3" id="menu-toggle"></i>
                    <h6 class="fs-5 m-0">Add Product</h6>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Admin
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="manage_account.php">Manage Profile</a></li>
                                <li><a class="dropdown-item" href="user_account.php">User</a></li>
                                <li><a class="dropdown-item" href="logout.php?logout">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="container">
                 <form action="import_process.php" method="post">
                     <div class="row">
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#import">
                                        Import
                                   </button>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Product Code:</label>
                                   <input type="text" class="form-control" id="usr" name="product_code" placeholder="Enter product code" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Product Name:</label>
                                   <input type="text" class="form-control" id="usr" name="product_name" placeholder="Enter product name" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Description:</label>
                                   <input type="text" class="form-control" id="usr" name="description" placeholder="Enter description" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Brand:</label>
                                   <input type="text" class="form-control" id="usr" name="brand" placeholder="Enter brand" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Supplier:</label>
                                   <input type="text" class="form-control" id="usr" name="supplier" placeholder="Enter supplier" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Price:</label>
                                   <input type="number" class="form-control" id="usr" name="price" placeholder="Enter price" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <label for="usr">Cost:</label>
                                   <input type="number" class="form-control" id="usr" name="cost" placeholder="Enter cost" required>
                               </div>
                         </div>
                         <div class="col-lg-12 col-sm-12 p-1">
                               <div class="form-group">
                                   <input type="submit" class="btn btn-primary" name="submit" value="Submit">
                               </div>
                         </div>
                      </div>
                   </form>
               </div>

            <!-- Modal start -->
               <div class="modal fade" id="import" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                      <div class="modal-content">
                          <div class="modal-header">
                               <h1 class="modal-title fs-5" id="exampleModalLabel">Import Product</h1>
                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form action="import_process.php" enctype="multipart/form-data" method="post">
                             <div class="modal-body">
                                  <div class="mb-3">
                                        <label for="formFile" class="form-label">File must be .xlsx</label>
                                        <input type="file" class="form-control" name="excel" required>
                                    </div>
                             </div>
                             <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <input type="submit" class="btn btn-primary" name="import" value="Import">
                              </div>
                          </form>
                     </div>
                 </div>
              </div>
            <!----modal end-->
        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function () {
            el.classList.toggle("toggled");
        };
    </script>
</body>

</html>
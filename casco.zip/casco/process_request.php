<?php

require 'connection.php';
require 'alert.php';

session_start();
$request_id = $_SESSION['request'];
$requestee = $_POST['requestee'];
$is_pending = 1;


if(isset($_POST['submit'])){
   
   $b_query = "SELECT * from branch WHERE branch_name='$requestee'";
   $b_result = mysqli_query($connection, $b_query) or die(mysqli_error($connection));
   $b_row = mysqli_fetch_array($b_result);

   @$br_name = $b_row['branch_name'];

   $req_temp_query = "SELECT * FROM `request_temp`";
   $req_temp_res = mysqli_query($connection,$req_temp_query);

   $req_temp_row = mysqli_fetch_array($req_temp_res);


   if($br_name == ""){

      echo "<script type='text/javascript'>
      swal({
         title: 'Branch Name not found',
         icon: 'warning',
      })
       .then((willDelete) => {
       if (willDelete) {
         window.location='request.php'
         }
         });
      </script>";
   }else if($req_temp_row <= 0){

     echo "<script type='text/javascript'>
      swal({
         title: 'No request item',
         icon: 'warning',
      })
       .then((willDelete) => {
       if (willDelete) {
         window.location='request.php'
         }
         });
      </script>";

   }else {

    $query = 'INSERT INTO `request` (`req_id`, `request_id`, `requestee`, `is_pending` ) VALUES (null, "'.$request_id.'", "'.$requestee.'", "'.$is_pending.'");';
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

    $query = 'INSERT INTO requested_items (product_id, request_id) SELECT product_id, request_id FROM request_temp WHERE request_id = "'.$request_id.'"; ';
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

    $query = 'DELETE FROM `request_temp` WHERE `request_id` = "'.$request_id.'"';
    $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

    unset($_SESSION['request']);

    echo "<script type='text/javascript'>
                      swal({
                         title: 'Your request has been saved',
                         icon: 'success',
                      })
                       .then((willDelete) => {
                       if (willDelete) {
                         window.location='req.php'
                         }
                         });
           </script>";

   }

} 


?>
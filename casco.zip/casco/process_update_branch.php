<?php

 require 'connection.php';
 require 'alert.php';

 if(isset($_POST['update'])){

     $query = "UPDATE `branch` SET `branch_manager`='".$_POST['branch_manager']."',`branch_name`='".$_POST['branch_name']."',
               `branch_address`='".$_POST['branch_address']."',`contact_no`='".$_POST['contact_no']."',`username`='".$_POST['username']."',
               `branch_password`='".$_POST['branch_password']."' WHERE `branch_id`='".$_POST['branch_id']."'";
   
    $result = mysqli_query($connection,$query);

    echo "<script type='text/javascript'>
     swal({
       title: 'The branch has been updated successfully',
       icon: 'success',
     })
     .then((willDelete) => {
     if (willDelete) {
       window.location='branch.php'
       }
       });
     </script>";  
 }

?>